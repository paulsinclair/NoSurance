﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoSuranceApp
{
    public class CustomerDetails
    {
        public DateTime policyStartDate;

        public Driver[] drivers;

        public DateTime[] getClaims()
        {
            List<DateTime> allClaimDates = new List<DateTime>();
            foreach (Driver driver in drivers)
            {
                foreach(DateTime claimDate in driver.claimDates)
                {
                    allClaimDates.Add(claimDate);
                }
            }
            return allClaimDates.ToArray();
        }

        public Boolean isValid()
        {
            return isStartDateValid()  && areDriversValid();
        }
        private Boolean isStartDateValid()
        {
            return !(policyStartDate == new DateTime());
        }
        public Boolean areDriversValid()
        {
            if (drivers == null || drivers.Length == 0) return false;
            return drivers[0].IsValid();
        }

        public Boolean hasOccupation(string occupation)
        {
            foreach(Driver driver in drivers)
            {
                if (driver.Occupation == occupation) return true;
            }
            return false;
        }

        public Boolean hasDriverUnder21()
        {
            DateTime TwentyOneYearsAgo = policyStartDate.AddYears(-21);

            foreach (Driver driver in drivers)
            {
                if (driver.dateOfBirth > TwentyOneYearsAgo)
                {
                    return true;
                }
            }
            return false;
        }

        public Boolean hasDriverOver75()
        {
            DateTime SeventyFiveYearsAgo = policyStartDate.AddYears(-75);

            foreach (Driver driver in drivers)
            {
                if (driver.dateOfBirth < SeventyFiveYearsAgo)
                {
                    return true;
                }
            }
            return false;
        }

        public Boolean isDriverWithMoreThen2Claims()
        {
            foreach (Driver driver in drivers)
            {
                if (driver.claimDates.Count > 2)
                {
                    return true;
                }
            }
            return false;
        }

        public Boolean isPolicyWithMoreThan3Claims()
        {
            int claimCount = 0;
            foreach (Driver driver in drivers)
            {
                claimCount = claimCount + driver.claimDates.Count;
            }
            return (claimCount > 3);
        }

        public string getDriverWithMoreThan2Claims()
        {
            foreach (Driver driver in drivers)
            {
                if (driver.claimDates.Count > 2)
                {
                    return driver.Name;
                }
            }
            return "";
        }

        public Boolean hasDriverUnder26()
        {
            DateTime TwentyFiveYearsAgo = policyStartDate.AddYears(-26);

            foreach (Driver driver in drivers)
            {
                if (driver.dateOfBirth > TwentyFiveYearsAgo)
                {
                    return true;
                }
            }
            return false;
        }
    }
    public class Driver
    {
        public DateTime dateOfBirth { get; set; }
        public string Occupation { get; set; }
        public string Name { get; set; }
        public List<DateTime> claimDates = new List<DateTime>();

        public Boolean IsValid()
        {
            if (dateOfBirth == new DateTime() 
                                || !(Occupation == "Accountant" || Occupation == "Chauffer")
                                || Name == null || Name.Trim().Length == 0)
            {
                return false;
            }
            else { 
            return true;
        }
        }

    }

    
}
