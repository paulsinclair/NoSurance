﻿namespace NoSuranceApp
{
    partial class QuoteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.desiredStartDate = new System.Windows.Forms.DateTimePicker();
            this.desStartDt = new System.Windows.Forms.Label();
            this.getQuote = new System.Windows.Forms.Button();
            this.quoteResults = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mainDoB = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.mainName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.mainOccupation = new System.Windows.Forms.ComboBox();
            this.addDriver = new System.Windows.Forms.Button();
            this.driverMessage = new System.Windows.Forms.Label();
            this.clearForm = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.dateOfClaim = new System.Windows.Forms.DateTimePicker();
            this.addClaim = new System.Windows.Forms.Button();
            this.AddClaimToDriver = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // desiredStartDate
            // 
            this.desiredStartDate.Location = new System.Drawing.Point(158, 27);
            this.desiredStartDate.Name = "desiredStartDate";
            this.desiredStartDate.Size = new System.Drawing.Size(200, 20);
            this.desiredStartDate.TabIndex = 0;
            this.desiredStartDate.ValueChanged += new System.EventHandler(this.desiredStartDate_ValueChanged);
            // 
            // desStartDt
            // 
            this.desStartDt.AutoSize = true;
            this.desStartDt.Location = new System.Drawing.Point(12, 27);
            this.desStartDt.Name = "desStartDt";
            this.desStartDt.Size = new System.Drawing.Size(125, 13);
            this.desStartDt.TabIndex = 1;
            this.desStartDt.Text = "Desired Policy Start Date";
            // 
            // getQuote
            // 
            this.getQuote.Enabled = false;
            this.getQuote.Location = new System.Drawing.Point(62, 314);
            this.getQuote.Name = "getQuote";
            this.getQuote.Size = new System.Drawing.Size(75, 23);
            this.getQuote.TabIndex = 2;
            this.getQuote.Text = "Get Quote";
            this.getQuote.UseVisualStyleBackColor = true;
            this.getQuote.Click += new System.EventHandler(this.button1_Click);
            // 
            // quoteResults
            // 
            this.quoteResults.AutoSize = true;
            this.quoteResults.Location = new System.Drawing.Point(338, 283);
            this.quoteResults.Name = "quoteResults";
            this.quoteResults.Size = new System.Drawing.Size(0, 13);
            this.quoteResults.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Driver Date Of Birth";
            // 
            // mainDoB
            // 
            this.mainDoB.Location = new System.Drawing.Point(158, 59);
            this.mainDoB.Name = "mainDoB";
            this.mainDoB.Size = new System.Drawing.Size(200, 20);
            this.mainDoB.TabIndex = 5;
            this.mainDoB.ValueChanged += new System.EventHandler(this.mainDoB_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Driver Name";
            // 
            // mainName
            // 
            this.mainName.Location = new System.Drawing.Point(158, 105);
            this.mainName.Name = "mainName";
            this.mainName.Size = new System.Drawing.Size(200, 20);
            this.mainName.TabIndex = 7;
            this.mainName.TextChanged += new System.EventHandler(this.mainName_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Driver Occupation";
            // 
            // mainOccupation
            // 
            this.mainOccupation.FormattingEnabled = true;
            this.mainOccupation.Items.AddRange(new object[] {
            "Accountant",
            "Chauffer"});
            this.mainOccupation.Location = new System.Drawing.Point(158, 152);
            this.mainOccupation.MaxDropDownItems = 2;
            this.mainOccupation.Name = "mainOccupation";
            this.mainOccupation.Size = new System.Drawing.Size(121, 21);
            this.mainOccupation.TabIndex = 9;
            this.mainOccupation.SelectedIndexChanged += new System.EventHandler(this.mainOccupation_SelectedIndexChanged);
            // 
            // addDriver
            // 
            this.addDriver.Location = new System.Drawing.Point(62, 221);
            this.addDriver.Name = "addDriver";
            this.addDriver.Size = new System.Drawing.Size(75, 23);
            this.addDriver.TabIndex = 10;
            this.addDriver.Text = "Add Driver";
            this.addDriver.UseVisualStyleBackColor = true;
            this.addDriver.Click += new System.EventHandler(this.addDriver_Click);
            // 
            // driverMessage
            // 
            this.driverMessage.AutoSize = true;
            this.driverMessage.Location = new System.Drawing.Point(158, 221);
            this.driverMessage.Name = "driverMessage";
            this.driverMessage.Size = new System.Drawing.Size(0, 13);
            this.driverMessage.TabIndex = 11;
            // 
            // clearForm
            // 
            this.clearForm.Location = new System.Drawing.Point(202, 313);
            this.clearForm.Name = "clearForm";
            this.clearForm.Size = new System.Drawing.Size(75, 23);
            this.clearForm.TabIndex = 12;
            this.clearForm.Text = "Clear Form";
            this.clearForm.UseVisualStyleBackColor = true;
            this.clearForm.Click += new System.EventHandler(this.clearForm_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(322, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Claim Date";
            // 
            // dateOfClaim
            // 
            this.dateOfClaim.Location = new System.Drawing.Point(418, 214);
            this.dateOfClaim.Name = "dateOfClaim";
            this.dateOfClaim.Size = new System.Drawing.Size(200, 20);
            this.dateOfClaim.TabIndex = 14;
            // 
            // addClaim
            // 
            this.addClaim.Enabled = false;
            this.addClaim.Location = new System.Drawing.Point(418, 254);
            this.addClaim.Name = "addClaim";
            this.addClaim.Size = new System.Drawing.Size(75, 23);
            this.addClaim.TabIndex = 15;
            this.addClaim.Text = "Add Claim";
            this.addClaim.UseVisualStyleBackColor = true;
            this.addClaim.Click += new System.EventHandler(this.addClaim_Click);
            // 
            // AddClaimToDriver
            // 
            this.AddClaimToDriver.AutoSize = true;
            this.AddClaimToDriver.Location = new System.Drawing.Point(418, 179);
            this.AddClaimToDriver.Name = "AddClaimToDriver";
            this.AddClaimToDriver.Size = new System.Drawing.Size(103, 13);
            this.AddClaimToDriver.TabIndex = 16;
            this.AddClaimToDriver.Text = "Add Claim to Driver: ";
            // 
            // QuoteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 349);
            this.Controls.Add(this.AddClaimToDriver);
            this.Controls.Add(this.addClaim);
            this.Controls.Add(this.dateOfClaim);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.clearForm);
            this.Controls.Add(this.driverMessage);
            this.Controls.Add(this.addDriver);
            this.Controls.Add(this.mainOccupation);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.mainName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mainDoB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.quoteResults);
            this.Controls.Add(this.getQuote);
            this.Controls.Add(this.desStartDt);
            this.Controls.Add(this.desiredStartDate);
            this.Name = "QuoteForm";
            this.Text = "Quote";
            this.Load += new System.EventHandler(this.QuoteForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker desiredStartDate;
        private System.Windows.Forms.Label desStartDt;
        private System.Windows.Forms.Button getQuote;
        private System.Windows.Forms.Label quoteResults;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker mainDoB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox mainName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox mainOccupation;
        private System.Windows.Forms.Button addDriver;
        private System.Windows.Forms.Label driverMessage;
        private System.Windows.Forms.Button clearForm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateOfClaim;
        private System.Windows.Forms.Button addClaim;
        private System.Windows.Forms.Label AddClaimToDriver;
    }
}

