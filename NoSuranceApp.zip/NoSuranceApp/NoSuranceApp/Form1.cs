﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NoSuranceApp
{
    public partial class QuoteForm : Form
    {
        private CustomerDetails customerDetails;
        //sprivate Driver[] drivers = new Driver[0];
        List<Driver> drivers = new List<Driver>();

        public QuoteForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            setCustomerDetails();
            QuoteCalculator quoteCalculator = new QuoteCalculator();

            if (customerDetails.isValid())
            {
                quoteResults.Text = quoteCalculator.getQuote(customerDetails);
            } else
            {
                quoteResults.Text = "Please Enter Valid Details.";
            }
        }

        private void QuoteForm_Load(object sender, EventArgs e)
        {

        }

        private void desiredStartDate_ValueChanged(object sender, EventArgs e)
        {
            validateForm();
        }

        private void validateForm()
        {
            setCustomerDetails();
            getQuote.Enabled = customerDetails.isValid();
        }

        private void setCustomerDetails()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = mainDoB.Value;
            driver.Occupation = mainOccupation.Text;
            driver.Name = mainName.Text;

            customerDetails = new CustomerDetails();
            customerDetails.policyStartDate = desiredStartDate.Value;
            customerDetails.drivers = drivers.ToArray();
        }

        private void mainName_TextChanged(object sender, EventArgs e)
        {
            validateForm();
        }

        private void mainDoB_ValueChanged(object sender, EventArgs e)
        {
            validateForm();
        }

        private void mainOccupation_SelectedIndexChanged(object sender, EventArgs e)
        {
            validateForm();
        }

        private void addDriver_Click(object sender, EventArgs e)
        {
            Driver driver = new Driver();

            driver.dateOfBirth = mainDoB.Value;
            driver.Occupation = mainOccupation.Text;
            driver.Name = mainName.Text;

            addDriverToListIfValid(driver);

            if (drivers.Count > 4) { addDriver.Enabled = false; }
            addClaim.Enabled = true;
            AddClaimToDriver.Text = "Add Claim to Driver: " + drivers.Last().Name;
        }

        private void addDriverToListIfValid(Driver driver)
        {
            if (driver.IsValid())
            {
                addValidDriverToDriverList(driver);
            }
            else
            {
                driverMessage.Text = "Please Enter Valid Driver";
            }
        }

        private void addValidDriverToDriverList(Driver driver)
        {
            drivers.Add(driver);
            driverMessage.Text = "Driver #" + drivers.Count.ToString() + " Added";
            clearDriverFields();
        }

        private void clearDriverFields()
        {
            mainDoB.Value = DateTime.Now;
            mainOccupation.Text = "";
            mainName.Text = "";
        }

        private void clearForm_Click(object sender, EventArgs e)
        {
            clearDriverFields();
            driverMessage.Text = "";
            desiredStartDate.Value = DateTime.Now;
            drivers = new List<Driver>();
        }

        private void addClaim_Click(object sender, EventArgs e)
        {
            drivers.Last().claimDates.Add(dateOfClaim.Value);

            AddClaimToDriver.Text = "Add Claim to Driver: " + drivers.Last().Name + " (" +
               drivers.Last().claimDates.Count + " Claims Added)";

            if (drivers.Last().claimDates.Count > 4) addClaim.Enabled = false;

        }
    }
}
