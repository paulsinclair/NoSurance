﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoSuranceApp
{
   public class QuoteCalculator
    {
        Decimal premium;
        CustomerDetails customerDetails;
        Boolean deniedQuote;
        string denialMessage;

        public string getQuote(CustomerDetails customerDetails)
        {
            this.customerDetails = customerDetails;

            setDenialFlagAndMessage();

            if (deniedQuote) return denialMessage;

            calculatePremium();

            return "£" + premium.ToString().Split('.')[0];
        }
        private void setDenialFlagAndMessage()
        {
            denialMessage = getDenialMessage();
            deniedQuote = (denialMessage != "");
        }

        private string getDenialMessage()
        {
            if (customerDetails.policyStartDate < DateTime.Now.AddDays(-1)) return "Start Date of Policy";
            if (customerDetails.hasDriverUnder21()) return "Age of Youngest Driver";
            if (customerDetails.hasDriverOver75()) return "Age of Oldest Driver";
            if (customerDetails.isDriverWithMoreThen2Claims()) return "Driver " + customerDetails.getDriverWithMoreThan2Claims() + " has more than two claims";
            if (customerDetails.isPolicyWithMoreThan3Claims()) return "Policy has more than 3 claims";
            return "";
        }
        private void calculatePremium()
        {
            premium = 500.00M;

            if (customerDetails.hasOccupation("Chauffer"))
            { premium = premium * 1.1M; }

            if (customerDetails.hasOccupation("Accountant"))
            { premium = premium * 0.9M; }

            if (customerDetails.hasDriverUnder26())
            { premium = premium * 1.2M; }
            else
            { premium = premium * 0.9M; }

            increasePremiumPerEachClaim();

      
        }

        private void increasePremiumPerEachClaim() {
            DateTime[] claims = customerDetails.getClaims();

            foreach (DateTime claim in claims)
            {
                if (claim > customerDetails.policyStartDate.AddYears(-1))
                {
                    premium = premium * 1.2M;
                }
                else
                {
                    if (claim > customerDetails.policyStartDate.AddYears(-5))
                    {
                        premium = premium * 1.1M;
                    }
                }
            }
        }
    }
}
