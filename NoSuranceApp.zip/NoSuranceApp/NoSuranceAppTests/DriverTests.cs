﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NoSuranceApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoSuranceApp.Tests
{
    [TestClass()]
    public class DriverTests
    {
        [TestMethod()]
        public void isValidReturnsFalseWithNoValuesSet()
        {
            Driver driver = new Driver();
            Assert.IsFalse(driver.IsValid());
        }
        [TestMethod()]
        public void isValidReturnsTrueWithValuesSet()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(1999, 1, 1);
            driver.Occupation = "Chauffer";
            driver.Name = "Test Name";
            Assert.IsTrue(driver.IsValid());
        }
        [TestMethod()]
        public void isValidReturnsFalseWithNoDoB()
        {
            Driver driver = new Driver();
            driver.Occupation = "Tester";
            driver.Name = "Test Name";
            Assert.IsFalse(driver.IsValid());
        }
        [TestMethod()]
        public void isValidReturnsFalseWithNoOccupation()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(1999, 1, 1);
            driver.Name = "Test Name";
            Assert.IsFalse(driver.IsValid());
        }
        [TestMethod()]
        public void isValidReturnsFalseWithNoName()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(1999, 1, 1);
            driver.Occupation = "Tester";
            Assert.IsFalse(driver.IsValid());
        }
    }
}