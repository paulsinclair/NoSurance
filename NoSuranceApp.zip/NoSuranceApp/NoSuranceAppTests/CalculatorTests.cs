﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NoSuranceApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace NoSuranceApp.Tests
{
    [TestClass()]
    public class CalculatorTests
    {
        [TestMethod()]
        public void getQuoteTestChauffer()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Chauffer";
            driver.Name = "Test Name";

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2030, 1, 1);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "£495");
        }
        [TestMethod()]
        public void getQuoteTestAccountant()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2030, 1, 1);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "£405");
        }

    [TestMethod()]
    public void getQuoteTestAccountantOver26()
    {
        Driver driver = new Driver();
        driver.dateOfBirth = new DateTime(2000, 1, 1);
        driver.Occupation = "Accountant";
        driver.Name = "Test Name";

        CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2030, 1, 1);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
        Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "£405");
    }

        [TestMethod()]
        public void getQuoteTestAccountantUnder26()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2025, 1, 1);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "£540");
        }

        [TestMethod()]
        public void getQuoteTestPolicyDateBeforeToday()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2000, 1, 1);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "Start Date of Policy");
        }

        [TestMethod()]
        public void getQuoteTestYoungDriver()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 2);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2021, 1, 1);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "Age of Youngest Driver");
        }

        [TestMethod()]
        public void getQuoteThreeClaimDriver()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 2);
            driver.Occupation = "Accountant";
            driver.Name = "Fred";
            driver.claimDates.Add(DateTime.Now.AddDays(-7));
            driver.claimDates.Add(DateTime.Now.AddDays(-30));
            driver.claimDates.Add(DateTime.Now.AddDays(-365));

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2030, 1, 1);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "Driver Fred has more than two claims");
        }

        [TestMethod()]
        public void getQuoteForFourClaimPolicy()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 2);
            driver.Occupation = "Accountant";
            driver.Name = "Fred";
            driver.claimDates.Add(DateTime.Now.AddDays(-7));
            driver.claimDates.Add(DateTime.Now.AddDays(-30));

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[2];
            customerDetails.drivers[0] = driver;
            customerDetails.drivers[1] = driver;
            customerDetails.policyStartDate = new DateTime(2030, 1, 1);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "Policy has more than 3 claims");
        }

        [TestMethod()]
        public void getQuoteTestOldDriver()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2075, 1, 2);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "Age of Oldest Driver");
        }
        [TestMethod()]
        public void getQuoteForPolicyWithOneRecentClaim()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            driver.claimDates.Add(new DateTime(2026, 1, 1));
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2026, 1, 2);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "£486");
        }
        [TestMethod()]
        public void getQuoteForPolicyWithOneFourYearOldClaim()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            driver.claimDates.Add(new DateTime(2026, 1, 1));
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;
            customerDetails.policyStartDate = new DateTime(2030, 1, 2);
            QuoteCalculator quoteCalculator = new QuoteCalculator();
            Assert.AreEqual(quoteCalculator.getQuote(customerDetails), "£445");
        }
    }
}