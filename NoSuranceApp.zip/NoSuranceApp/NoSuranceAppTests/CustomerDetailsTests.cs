﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NoSuranceApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoSuranceApp.Tests
{
    [TestClass()]
    public class CustomerDetailsTests
    {
        [TestMethod()]
        public void isValidReturnsFalseWithNoValuesSet()
        {
            CustomerDetails customerDetails = new CustomerDetails();
            Assert.IsFalse(customerDetails.isValid());
        }
        [TestMethod()]
        public void isValidReturnsFalseWithNoStartDateSet()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(1999, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;

            Assert.IsFalse(customerDetails.isValid());
        }
        [TestMethod()]
        public void isValidReturnsFalseWithNoDriver()
        {

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.policyStartDate = new DateTime(1999, 1, 1);

            Assert.IsFalse(customerDetails.isValid());
        }
        [TestMethod()]
        public void isValidReturnsTrueWithValuesSet()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(1999, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[1];
            customerDetails.drivers[0] = driver;

            customerDetails.policyStartDate = new DateTime(1999, 1, 1);

            Assert.IsTrue(customerDetails.isValid());
        }

        [TestMethod()]
        public void areDriversValidTest()
        {
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = null;
            Assert.IsFalse(customerDetails.areDriversValid());
        }

        [TestMethod()]
        public void hasOccupationReturnsFalseIfNoDriverWithOccupation()
        {
            Driver accountantDriver = new Driver();
            accountantDriver.dateOfBirth = new DateTime(1999, 1, 1);
            accountantDriver.Occupation = "Accountant";
            accountantDriver.Name = "Test Name";
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[4];
            customerDetails.drivers[0] = accountantDriver;
            customerDetails.drivers[1] = accountantDriver;
            customerDetails.drivers[2] = accountantDriver;
            customerDetails.drivers[3] = accountantDriver;

            customerDetails.policyStartDate = new DateTime(1999, 1, 1);

            Assert.IsFalse(customerDetails.hasOccupation("Chauffer"));
            Assert.IsTrue(customerDetails.hasOccupation("Accountant"));

        }

        [TestMethod()]
        public void hasOccupationReturnsTrueIfHasOccupation()
        {
            Driver accountantDriver = new Driver();
            accountantDriver.dateOfBirth = new DateTime(1999, 1, 1);
            accountantDriver.Occupation = "Accountant";
            accountantDriver.Name = "Test Name";
            Driver chaufferDriver = new Driver();
            chaufferDriver.dateOfBirth = new DateTime(1999, 1, 1);
            chaufferDriver.Occupation = "Chauffer";
            chaufferDriver.Name = "Test Name";
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[5];
            customerDetails.drivers[0] = accountantDriver;
            customerDetails.drivers[1] = accountantDriver;
            customerDetails.drivers[2] = chaufferDriver;
            customerDetails.drivers[3] = accountantDriver;
            customerDetails.drivers[3] = accountantDriver;

            customerDetails.policyStartDate = new DateTime(1999, 1, 1);

            Assert.IsTrue(customerDetails.hasOccupation("Chauffer"));
            Assert.IsTrue(customerDetails.hasOccupation("Accountant"));
        }

        [TestMethod()]
        public void hasDriverUnder21TestReturnsTrueForUnder21()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            Driver youngDriver = new Driver();
            youngDriver.dateOfBirth = new DateTime(2000, 1, 2);
            youngDriver.Occupation = "Chauffer";
            youngDriver.Name = "Test Name";
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.policyStartDate = new DateTime(2021, 1, 1);
            customerDetails.drivers = new Driver[5];
            customerDetails.drivers[0] = driver;
            customerDetails.drivers[1] = driver;
            customerDetails.drivers[2] = youngDriver;
            customerDetails.drivers[3] = driver;
            customerDetails.drivers[4] = driver;


            Assert.IsTrue(customerDetails.hasDriverUnder21());
        }
        [TestMethod()]
        public void hasDriverUnder21TestReturnsFalseForNoUnder21()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            Driver youngDriver = new Driver();
            youngDriver.dateOfBirth = new DateTime(2000, 1, 1);
            youngDriver.Occupation = "Chauffer";
            youngDriver.Name = "Test Name";
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.policyStartDate = new DateTime(2021, 1, 2);
            customerDetails.drivers = new Driver[5];
            customerDetails.drivers[0] = driver;
            customerDetails.drivers[1] = driver;
            customerDetails.drivers[2] = youngDriver;
            customerDetails.drivers[3] = driver;
            customerDetails.drivers[4] = driver;


            Assert.IsFalse(customerDetails.hasDriverUnder21());
        }

        [TestMethod()]
        public void hasDriverUnder26Test()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 1);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            Driver youngDriver = new Driver();
            youngDriver.dateOfBirth = new DateTime(2000, 1, 2);
            youngDriver.Occupation = "Chauffer";
            youngDriver.Name = "Test Name";
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.policyStartDate = new DateTime(2026, 1, 1);
            customerDetails.drivers = new Driver[5];
            customerDetails.drivers[0] = driver;
            customerDetails.drivers[1] = driver;
            customerDetails.drivers[2] = youngDriver;
            customerDetails.drivers[3] = driver;
            customerDetails.drivers[4] = driver;


            Assert.IsTrue(customerDetails.hasDriverUnder26());
        }

        [TestMethod()]
        public void hasDriverOver75Test()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 2);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            Driver oldDriver = new Driver();
            oldDriver.dateOfBirth = new DateTime(2000, 1, 1);
            oldDriver.Occupation = "Chauffer";
            oldDriver.Name = "Test Name";
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.policyStartDate = new DateTime(2075, 1, 2);
            customerDetails.drivers = new Driver[5];
            customerDetails.drivers[0] = driver;
            customerDetails.drivers[1] = driver;
            customerDetails.drivers[2] = oldDriver;
            customerDetails.drivers[3] = driver;
            customerDetails.drivers[4] = driver;


            Assert.IsTrue(customerDetails.hasDriverOver75());
        }

        [TestMethod()]
        public void isDriverWithMoreThen2ClaimsTest()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 2);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            Driver driverWithThreeClaims = new Driver();
            driverWithThreeClaims.dateOfBirth = new DateTime(2000, 1, 1);
            driverWithThreeClaims.Occupation = "Chauffer";
            driverWithThreeClaims.Name = "Two Claim Driver";
            driverWithThreeClaims.claimDates.Add(DateTime.Now);
            driverWithThreeClaims.claimDates.Add(DateTime.Now);
            driverWithThreeClaims.claimDates.Add(DateTime.Now);
            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.policyStartDate = new DateTime(2075, 1, 2);
            customerDetails.drivers = new Driver[5];
            customerDetails.drivers[0] = driver;
            customerDetails.drivers[1] = driver;
            customerDetails.drivers[2] = driverWithThreeClaims;
            customerDetails.drivers[3] = driver;
            customerDetails.drivers[4] = driver;

            Assert.IsTrue(customerDetails.isDriverWithMoreThen2Claims());
            Assert.AreEqual("Two Claim Driver", customerDetails.getDriverWithMoreThan2Claims());
        }

        [TestMethod()]
        public void isPolicyWithMoreThan3ClaimsTest()
        {
            Driver driver = new Driver();
            driver.dateOfBirth = new DateTime(2000, 1, 2);
            driver.Occupation = "Accountant";
            driver.Name = "Test Name";
            driver.claimDates.Add(DateTime.Now.AddDays(-30));

            CustomerDetails customerDetails = new CustomerDetails();
            customerDetails.policyStartDate = new DateTime(2075, 1, 2);
            customerDetails.drivers = new Driver[3];
            customerDetails.drivers[0] = driver;
            customerDetails.drivers[1] = driver;
            customerDetails.drivers[2] = driver;

            Assert.IsFalse(customerDetails.isPolicyWithMoreThan3Claims());

            customerDetails.drivers = new Driver[4];
            customerDetails.drivers[0] = driver;
            customerDetails.drivers[1] = driver;
            customerDetails.drivers[2] = driver;
            customerDetails.drivers[3] = driver;

            Assert.IsTrue(customerDetails.isPolicyWithMoreThan3Claims());
        }

        [TestMethod()]
        public void getClaimsTest()
        {
            CustomerDetails customerDetails = new CustomerDetails();

            Driver driverWithClaim = new Driver();
            driverWithClaim.claimDates.Add(DateTime.Now.AddDays(-30));
            Driver driverWithNoClaim = new Driver();
            Driver driverWithFiveClaims = new Driver();
            driverWithFiveClaims.claimDates.Add(DateTime.Now.AddDays(-30));
            driverWithFiveClaims.claimDates.Add(DateTime.Now.AddDays(-30));
            driverWithFiveClaims.claimDates.Add(DateTime.Now.AddDays(-30));
            driverWithFiveClaims.claimDates.Add(DateTime.Now.AddDays(-30));
            driverWithFiveClaims.claimDates.Add(DateTime.Now.AddDays(-30));

            customerDetails.drivers = new Driver[4];
            customerDetails.drivers[0] = driverWithNoClaim;
            customerDetails.drivers[1] = driverWithNoClaim;
            customerDetails.drivers[2] = driverWithNoClaim;
            customerDetails.drivers[3] = driverWithClaim;

            Assert.AreEqual(1, customerDetails.getClaims().Length);


            customerDetails.drivers = new Driver[4];
            customerDetails.drivers[0] = driverWithClaim;
            customerDetails.drivers[1] = driverWithClaim;
            customerDetails.drivers[2] = driverWithClaim;
            customerDetails.drivers[3] = driverWithClaim;

            Assert.AreEqual(4, customerDetails.getClaims().Length);

            customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[4];
            customerDetails.drivers[0] = driverWithNoClaim;
            customerDetails.drivers[1] = driverWithNoClaim;
            customerDetails.drivers[2] = driverWithNoClaim;
            customerDetails.drivers[3] = driverWithNoClaim;

            Assert.AreEqual(0, customerDetails.getClaims().Length);

            customerDetails = new CustomerDetails();
            customerDetails.drivers = new Driver[4];
            customerDetails.drivers[0] = driverWithNoClaim;
            customerDetails.drivers[1] = driverWithNoClaim;
            customerDetails.drivers[2] = driverWithNoClaim;
            customerDetails.drivers[3] = driverWithFiveClaims;

            Assert.AreEqual(5, customerDetails.getClaims().Length);
        }
    }
}